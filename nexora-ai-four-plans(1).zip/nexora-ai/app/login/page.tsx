'use client';
import { useState } from 'react';
import { getSupabase } from '@/lib/supabase';
export default function Login() {
  const [email,setEmail]=useState(''); const [status,setStatus]=useState(''); const [busy,setBusy]=useState(false);
  async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setStatus('');try{const supabase=getSupabase();const {error}=await supabase.auth.signInWithOtp({email,options:{emailRedirectTo:window.location.origin}});if(error)throw error;setStatus('Check your inbox for your sign-in link.');}catch(err){setStatus(err instanceof Error?err.message:'Sign-in could not be started.');}finally{setBusy(false);}}
  return <main className="auth-page"><a className="brand" href="/"><span className="brand-mark">N</span>NEXORA<span className="brand-light"> AI</span></a><form className="auth-card" onSubmit={submit}><span className="eyebrow">YOUR WORKSPACE AWAITS</span><h1>Welcome back.</h1><p>Enter your email and we'll send you a secure sign-in link.</p><label>Email address</label><input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/><button disabled={busy}>{busy?'Sending…':'Send sign-in link →'}</button>{status&&<small>{status}</small>}<a className="back-link" href="/">← Back to NEXORA</a></form><small className="auth-foot">Preview sign-in requires a configured Supabase project.</small></main>;
}
