'use client';
import { ChangeEvent, useRef, useState } from 'react';

type Message = { role: 'user' | 'assistant'; content: string; imageData?: string; generatedImage?: string };
const suggestions = ['Explain a difficult topic simply', 'Help me plan a creative project', 'Draw a simple science diagram'];
const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<'chat' | 'image'>('chat');
  const [attachment, setAttachment] = useState<{ data: string; name: string } | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);

  async function readImage(file?: File) {
    if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/webp', 'image/gif'].includes(file.type)) {
      alert('Please choose a PNG, JPG, WEBP, or GIF image.');
      return;
    }
    if (file.size > MAX_IMAGE_BYTES) {
      alert('Please choose an image smaller than 5 MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setAttachment({ data: String(reader.result), name: file.name });
    reader.readAsDataURL(file);
  }

  async function send(text = input, requestedMode: 'chat' | 'image' = mode) {
    const prompt = text.trim();
    if ((!prompt && !attachment) || busy) return;
    const userMessage: Message = {
      role: 'user',
      content: prompt || 'Please look at this image and help me understand it.',
      ...(attachment ? { imageData: attachment.data } : {}),
    };
    const next = [...messages, userMessage];
    setMessages(next);
    setInput('');
    setAttachment(null);
    setBusy(true);
    try {
      if (requestedMode === 'image') {
        const res = await fetch('/api/images', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: userMessage.content }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Image creation failed.');
        setMessages([...next, { role: 'assistant', content: 'Here is your creation. You can ask me to make another version or change the style.', generatedImage: data.image }]);
      } else {
        const res = await fetch('/api/chat', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ messages: next }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Something went wrong.');
        setMessages([...next, { role: 'assistant', content: data.reply }]);
      }
    } catch (e) {
      setMessages([...next, { role: 'assistant', content: e instanceof Error ? e.message : 'Unable to reach NEXORA right now.' }]);
    } finally { setBusy(false); }
  }

  function onFileChange(event: ChangeEvent<HTMLInputElement>) {
    void readImage(event.target.files?.[0]);
    event.target.value = '';
  }

  return <main className="shell">
    <aside className="sidebar"><a className="brand" href="/"><span className="brand-mark">N</span><span>NEXORA<span className="brand-light"> AI</span></span></a><button className="new-chat" onClick={() => { setMessages([]); setAttachment(null); }}>＋ <span>New conversation</span></button><div className="side-label">WORKSPACE</div><a className="side-link active" href="/">✧ <span>AI Assistant</span></a><a className="side-link" href="#features">◈ <span>Explore features</span></a><a className="side-link" href="#plans">◇ <span>Plans</span></a><div className="side-bottom"><div className="avatar">G</div><div><b>Guest workspace</b><small>Preview mode</small></div><a className="signin-small" href="/login">Sign in</a></div></aside>
    <section className="main"><header className="topbar"><div className="crumb">Workspace <span>/</span> <b>Assistant</b></div><div className="top-actions"><span className="status-dot"/> Preview environment <a className="upgrade" href="#plans">Explore plans ↗</a></div></header>
      <div className={`chat-area ${messages.length ? 'has-messages' : ''}`}>{messages.length === 0 ? <div className="welcome"><div className="orb"><span>✧</span></div><div className="eyebrow">YOUR INTELLIGENCE, AMPLIFIED</div><h1>Think beyond<br/><em>what's possible.</em></h1><p>Meet your AI workspace for clearer thinking, creative momentum, and better questions.</p><div className="suggestions">{suggestions.map(s => <button key={s} onClick={() => { if (s.startsWith('Draw')) { setMode('image'); void send(s, 'image'); } else { void send(s, 'chat'); } }}>{s}<span>↗</span></button>)}</div></div> : <div className="messages">{messages.map((m,i)=><article className={`message ${m.role}`} key={i}><div className="message-icon">{m.role === 'user' ? 'Y' : 'N'}</div><div className="message-body"><div className="message-role">{m.role === 'user' ? 'YOU' : 'NEXORA'}</div><p>{m.content}</p>{m.imageData && <img className="attachment-preview" src={m.imageData} alt="User uploaded"/>}{m.generatedImage && <img className="generated-preview" src={m.generatedImage} alt="Image generated by NEXORA AI"/>}</div></article>)}{busy && <div className="typing">NEXORA is {mode === 'image' ? 'creating your image' : 'thinking'}<span> ···</span></div>}</div>}</div>
      <div className="composer-wrap">
        {attachment && <div className="attachment-chip"><img src={attachment.data} alt="Selected upload"/><span>{attachment.name}</span><button type="button" onClick={() => setAttachment(null)} aria-label="Remove image">×</button></div>}
        <form className="composer" onSubmit={e=>{e.preventDefault();void send();}}>
          <input ref={fileRef} className="hidden-file" type="file" accept="image/png,image/jpeg,image/webp,image/gif" onChange={onFileChange}/>
          <input ref={cameraRef} className="hidden-file" type="file" accept="image/*" capture="environment" onChange={onFileChange}/>
          <div className="composer-tools"><button type="button" className="tool-button" title="Upload a picture" aria-label="Upload a picture" onClick={()=>fileRef.current?.click()}>＋</button><button type="button" className="tool-button camera-button" title="Take a picture" aria-label="Take a picture" onClick={()=>cameraRef.current?.click()}>◎</button></div>
          <textarea value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();void send();}}} placeholder={mode === 'image' ? 'Describe what you want NEXORA to draw…' : 'Ask NEXORA anything…'} rows={1}/>
          <button type="button" className={`mode-button ${mode === 'image' ? 'selected' : ''}`} onClick={()=>setMode(mode === 'chat' ? 'image' : 'chat')} title="Switch between chat and image creation">{mode === 'image' ? '✧ Draw' : '✧ Create'}</button>
          <button disabled={(!input.trim()&&!attachment)||busy} aria-label="Send message">↑</button>
        </form><div className="disclaimer">{mode === 'image' ? 'Image creation may take a little while. Generated images can contain mistakes.' : 'Upload a picture for help, or switch to Create to generate a sketch or image.'}</div>
      </div>
      <section id="features" className="below"><div><span className="eyebrow">BUILT FOR MOMENTUM</span><h2>One workspace.<br/>More possibilities.</h2></div><div className="feature-grid"><div className="feature"><b>✧ Thoughtful answers</b><p>Explore ideas and make complex topics easier to understand.</p></div><div className="feature"><b>◈ Photo understanding</b><p>Upload a picture or take one and ask NEXORA to explain what it sees.</p></div><div className="feature"><b>✎ AI image creation</b><p>Turn a description into an original illustration, sketch, or diagram.</p></div></div></section>
      <section id="plans" className="plans"><span className="eyebrow">SIMPLE MEMBERSHIPS</span><h2>Choose your pace.</h2><div className="plan-grid"><div className="plan"><span>STARTER</span><h3>Free</h3><p>Explore the NEXORA experience.</p><a href="/login">Get started ↗</a></div><div className="plan"><span>SPARK · PREVIEW</span><h3>$5.99<small>/ month</small></h3><p>A little more room to explore, create, and learn.</p><a href="/login">Join waitlist ↗</a></div><div className="plan featured"><span>PRO · PREVIEW</span><h3>$14.99<small>/ month</small></h3><p>For deeper, more frequent work.</p><a href="/login">Join waitlist ↗</a></div><div className="plan"><span>ULTRA · PREVIEW</span><h3>$29.99<small>/ month</small></h3><p>For ambitious projects and workflows.</p><a href="/login">Join waitlist ↗</a></div></div><small className="billing-note">Displayed prices are proposed plans only. Payments are not enabled in this preview.</small></section>
      <footer>NEXORA AI <span>© 2026 · Built for what's next.</span></footer>
    </section>
  </main>;
}
