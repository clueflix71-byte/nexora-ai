import OpenAI from 'openai';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const maxDuration = 60;

export async function POST(request: Request) {
  if (!process.env.OPENAI_API_KEY) {
    return NextResponse.json({ error: 'Image creation is not connected yet. Add OPENAI_API_KEY in your hosting environment.' }, { status: 503 });
  }

  try {
    const body = await request.json();
    const prompt = typeof body.prompt === 'string' ? body.prompt.trim() : '';
    if (!prompt || prompt.length > 1800) {
      return NextResponse.json({ error: 'Please enter a description of up to 1,800 characters.' }, { status: 400 });
    }

    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const result = await openai.images.generate({
      model: process.env.OPENAI_IMAGE_MODEL || 'gpt-image-2.5-flare',
      prompt: `Create an original, safe, useful visual based on this request. If a diagram, sketch, or educational illustration is requested, make it clear and easy to understand. Request: ${prompt}`,
      size: '1024x1024',
    });

    const image = result.data?.[0]?.b64_json;
    if (!image) return NextResponse.json({ error: 'The image service did not return an image. Please try again.' }, { status: 502 });
    return NextResponse.json({ image: `data:image/png;base64,${image}` });
  } catch {
    return NextResponse.json({ error: 'Image creation failed. Check that image generation is enabled for your API account, then try again.' }, { status: 500 });
  }
}
