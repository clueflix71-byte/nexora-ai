import OpenAI from 'openai';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

const allowedImageTypes = new Set(['image/png', 'image/jpeg', 'image/webp', 'image/gif']);

export async function POST(request: Request) {
  if (!process.env.OPENAI_API_KEY) {
    return NextResponse.json({ error: 'AI is not connected yet. Add OPENAI_API_KEY in your hosting environment.' }, { status: 503 });
  }

  try {
    const body = await request.json();
    if (!Array.isArray(body.messages) || body.messages.length === 0 || body.messages.length > 30) {
      return NextResponse.json({ error: 'Please send a valid conversation.' }, { status: 400 });
    }

    const messages = body.messages
      .filter((m: any) => ['user', 'assistant'].includes(m?.role) && typeof m?.content === 'string')
      .map((m: any) => {
        const content: any[] = [{ type: 'text', text: m.content.slice(0, 6000) }];
        if (m.role === 'user' && typeof m.imageData === 'string') {
          const match = m.imageData.match(/^data:(image\/(?:png|jpeg|webp|gif));base64,([A-Za-z0-9+/=]+)$/);
          if (!match || m.imageData.length > 7_000_000 || !allowedImageTypes.has(match[1])) {
            throw new Error('That image is not supported or is too large. Please use PNG, JPG, WEBP, or GIF under 5 MB.');
          }
          content.push({ type: 'image_url', image_url: { url: m.imageData, detail: 'high' } });
        }
        return { role: m.role, content: m.imageData && m.role === 'user' ? content : m.content.slice(0, 6000) };
      });

    if (!messages.length) return NextResponse.json({ error: 'No valid message was provided.' }, { status: 400 });
    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const result = await openai.chat.completions.create({
      model: process.env.OPENAI_VISION_MODEL || process.env.OPENAI_MODEL || 'gpt-4.1-mini',
      messages,
      max_tokens: 1400,
    });
    return NextResponse.json({ reply: result.choices[0]?.message?.content || 'I could not generate a response.' });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'The AI request failed. Please try again.';
    const status = message.startsWith('That image') ? 400 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
