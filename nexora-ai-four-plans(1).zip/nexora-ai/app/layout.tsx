import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'NEXORA AI — Think Beyond', description: 'A premium AI workspace for ideas, learning, and creation.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
