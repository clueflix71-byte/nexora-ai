# NEXORA AI — futuristic AI workspace starter

A Next.js website starter with an OpenAI-powered chat API, image understanding for uploaded photos, AI image generation, a Supabase magic-link sign-in page, pricing preview with Free, Spark, Pro, and Ultra tiers, and an admin dashboard placeholder.

## Features in this build
- Text chat through the OpenAI Chat Completions API.
- Upload PNG, JPG, WEBP, or GIF pictures (up to 5 MB) and ask questions about them.
- On supported mobile browsers, use the camera button to take a picture and attach it to a chat.
- Switch to **Create** mode to generate an illustration, sketch, or diagram from a text description.
- Futuristic responsive dark interface.

## Run locally
1. Install Node.js 20 or newer and a code editor.
2. Extract the project and open its folder in a terminal.
3. Run `npm install`.
4. Copy `.env.example` to `.env.local` and add your server-side `OPENAI_API_KEY`.
5. Run `npm run dev` and open `http://localhost:3000`.

The homepage can render without keys. Chat and photo understanding require an OpenAI API key and a vision-capable chat model. Image creation requires API access to the configured image model (`gpt-image-2.5-flare` by default); access or organization verification may be required by OpenAI. Image API usage can incur additional charges. Keep API keys on the server and never share them in chat or commit `.env.local`.

## Before a public launch
This is a starter, not a production-ready SaaS. The following work is still required:
- Add server-side authentication checks to the chat and image APIs and protect private routes.
- Add per-user rate limits, usage quotas, image-generation limits, abuse prevention, logging, and monitoring.
- Configure Supabase redirect URLs and production auth policies.
- Implement real billing with a payment provider, verified webhooks, subscription state, refunds, and cancellation flows. Proposed monthly prices shown on the page are Free ($0), Spark ($5.99), Pro ($14.99), and Ultra ($29.99). Prices are examples only; checkout is not enabled.
- Replace the admin preview with server-verified admin roles and secure analytics.
- Add persistent conversation storage, privacy policy, terms, data deletion, and security review.
- Configure deployment environment variables and a custom domain.

Because hosting and payment accounts involve account ownership and billing, a parent/guardian or other trusted adult should own and approve those accounts. Do not send API keys or passwords in this project chat.
